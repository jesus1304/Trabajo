package com.example.demo.controladores;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.modelo.Cliente;
import com.example.demo.modelo.Proveedor;
import com.example.demo.servicios.FirebaseInitializer;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;
import com.google.firestore.v1beta1.WriteResult;

@RestController
public class ProveedorController {
@Autowired
FirebaseInitializer db;

//CRUD
@GetMapping("/listarProveedores")
public List<Proveedor> listarProveedores() throws InterruptedException, ExecutionException {
    List<Proveedor> listaProveedores = new ArrayList<>();
    CollectionReference proveedores = db.getFirebase().collection("proveedor");
    ApiFuture<QuerySnapshot> querySnapshot = proveedores.get();
    for (DocumentSnapshot doc : querySnapshot.get().getDocuments()) {
        Proveedor proveedor = doc.toObject(Proveedor.class);
        listaProveedores.add(proveedor);
    }
    return listaProveedores;
}

@PostMapping("/guardarProveedor")
public ResponseEntity<String> guardarProveedor(@RequestBody Proveedor proveedor) {
    try {
        CollectionReference proveedoresCollection = db.getFirebase().collection("proveedor");
        proveedoresCollection.document().set(proveedor);
        return ResponseEntity.ok("Proveedor guardado correctamente");
    } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error al guardar el proveedor: " + e.getMessage());
    }
}



}