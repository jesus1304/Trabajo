package com.example.demo.controladores;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.modelo.Cliente;
import com.example.demo.servicios.FirebaseInitializer;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;
import com.google.firestore.v1beta1.WriteResult;

@RestController
public class ClienteController {
@Autowired
FirebaseInitializer db;

//CRUD
@GetMapping("/listarClientes")
public List<Cliente> listarClientes() throws InterruptedException, ExecutionException{
	List<Cliente>listaClientes=new ArrayList<Cliente>();
	CollectionReference clientes = db.getFirebase().collection("cliente");
    ApiFuture<QuerySnapshot> querySnapshot = clientes.get();
    for (DocumentSnapshot doc : querySnapshot.get().getDocuments()) {
        Cliente c = doc.toObject(Cliente.class);
       listaClientes.add(c);
    }
    return listaClientes;
}
@PostMapping("/guardarCliente")
public ResponseEntity<String> guardarCliente(@RequestBody Cliente c1) {
    try {
        CollectionReference clientesCollection = db.getFirebase().collection("cliente");
        clientesCollection.document().set(c1);
        return ResponseEntity.ok("Clientes guardados correctamente");
    } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error al guardar los clientes: " + e.getMessage());
    }
}
@DeleteMapping("/eliminarCliente/{idCliente}")
public ResponseEntity<String> eliminarCliente(@PathVariable int idCliente) {
    try {
        db.getFirebase().collection("cliente").document(String.valueOf(idCliente)).delete();
        return ResponseEntity.ok("Cliente eliminado correctamente");
    } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error al eliminar el cliente: " + e.getMessage());
    }
}

}