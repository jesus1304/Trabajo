package com.example.demo.modelo;

import org.springframework.stereotype.Component;

@Component
public class Proveedor {
	private int idProovedor;
	private String telefono;

	private String apellido;
	private String correo;
	private String nombre;
	
	
	
	public Proveedor(String telefono, String apellido, String correo, String nombre) {
		super();
		this.telefono = telefono;
		this.apellido = apellido;
		this.correo = correo;
		this.nombre = nombre;
	}
	public Proveedor() {
		super();
	}
	public Proveedor(int idProovedor, String telefono, String apellido, String correo, 
			String nombre) {
		super();
		this.idProovedor = idProovedor;
		this.telefono = telefono;
		this.apellido = apellido;
		this.correo = correo;
		this.nombre = nombre;
	}
	public int getIdProovedor() {
		return idProovedor;
	}
	public void setIdProovedor(int idProovedor) {
		this.idProovedor = idProovedor;
	}
	public String getTelefono() {
		return telefono;
	}
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getCorreo() {
		return correo;
	}
	public void setCorreo(String correo) {
		this.correo = correo;
	}
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	@Override
	public String toString() {
		return "Proveedor [idProovedor=" + idProovedor + ", telefono=" + telefono + ", apellido=" + apellido
				+ ", correo=" + correo + ", nombre=" + nombre + ", getIdProovedor()=" + getIdProovedor()
				+ ", getTelefono()=" + getTelefono() + ", getApellido()=" + getApellido() + ", getCorreo()="
				+ getCorreo() + ", getNombre()=" + getNombre() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() + "]";
	}

}
