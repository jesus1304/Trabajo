package com.example.demo.controladores;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.modelo.Cliente;
import com.example.demo.modelo.Factura;
import com.example.demo.servicios.FirebaseInitializer;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;
import com.google.firestore.v1beta1.WriteResult;

@RestController
public class FacturaController {
@Autowired
FirebaseInitializer db;

//CRUD
@GetMapping("/listarFacturas")
public List<Factura> listarFacturas() throws InterruptedException, ExecutionException {
    List<Factura> listaFacturas = new ArrayList<>();
    CollectionReference facturas = db.getFirebase().collection("factura");
    ApiFuture<QuerySnapshot> querySnapshot = facturas.get();
    for (DocumentSnapshot doc : querySnapshot.get().getDocuments()) {
        Factura factura = doc.toObject(Factura.class);
        listaFacturas.add(factura);
    }
    return listaFacturas;
}

}