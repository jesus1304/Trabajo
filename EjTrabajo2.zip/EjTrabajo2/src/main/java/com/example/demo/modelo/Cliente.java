package com.example.demo.modelo;

import org.springframework.stereotype.Component;

import com.google.gson.annotations.SerializedName;

@Component

public class Cliente {

    private String nombre;

    private int idCliente;

    private String telefono;

    private String correo;

    private String user;

    private String apellido;

    private String contraseña;

    // Constructor vacío
    public Cliente() {
    }

    // Constructor con todos los campos
    public Cliente(String nombre, int idCliente, String telefono, String correo, String user, String apellido, String contraseña) {
        this.nombre = nombre;
        this.idCliente = idCliente;
        this.telefono = telefono;
        this.correo = correo;
        this.user = user;
        this.apellido = apellido;
        this.contraseña = contraseña;
    }
		public int getIdCliente() {
			return idCliente;
		}
		public void setIdCliente(int idCliente) {
			this.idCliente = idCliente;
		}
		public String getTelefono() {
			return telefono;
		}
		public void setTelefono(String telefono) {
			this.telefono = telefono;
		}
		public String getApellido() {
			return apellido;
		}
		public void setApellido(String apellido) {
			this.apellido = apellido;
		}
		public String getContraseña() {
			return contraseña;
		}
		public void setContraseña(String contraseña) {
			this.contraseña = contraseña;
		}
		public String getCorreo() {
			return correo;
		}
		public void setCorreo(String correo) {
			this.correo = correo;
		}
		public String getUser() {
			return user;
		}
		public void setUser(String user) {
			this.user = user;
		}
		public String getNombre() {
			return nombre;
		}
		public void setNombre(String nombre) {
			this.nombre = nombre;
		}
		@Override
		public String toString() {
			return "Cliente [idCliente=" + idCliente + ", telefono=" + telefono + ", apellido=" + apellido + ", contraseña="
					+ contraseña + ", correo=" + correo + ", user=" + user + ", nombre=" + nombre + ", getIdCliente()="
					+ getIdCliente() + ", getTelefono()=" + getTelefono() + ", getApellido()=" + getApellido()
					+ ", getContraseña()=" + getContraseña() + ", getCorreo()=" + getCorreo() + ", getUser()=" + getUser()
					+ ", getNombre()=" + getNombre() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
					+ ", toString()=" + super.toString() + "]";
		}
		
		
		
	}

