package com.nebrija.javafx_holamundo;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import javafx.beans.property.*;

import java.time.LocalDate;

public class Persona {

    private StringProperty nombre;
    private StringProperty direccion;
    private IntegerProperty precio;
    private ObjectProperty<LocalDate> fecha;

    public Persona(String nombre, int precio, String direccion, LocalDate fecha) {
        this.nombre = new SimpleStringProperty(nombre);
        this.precio = new SimpleIntegerProperty(precio);
        this.direccion = new SimpleStringProperty(direccion);
        this.fecha = new SimpleObjectProperty<>(fecha);
    }

    // Getters and setters for nombre
    public String getNombre() {
        return nombre.get();
    }

    public StringProperty nombreProperty() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre.set(nombre);
    }

    // Getters and setters for precio
    public int getPrecio() {
        return precio.get();
    }

    public IntegerProperty precioProperty() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio.set(precio);
    }

    // Getters and setters for direccion
    public String getDireccion() {
        return direccion.get();
    }

    public StringProperty direccionProperty() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion.set(direccion);
    }

    // Getters and setters for fecha
    public LocalDate getFecha() {
        return fecha.get();
    }

    public ObjectProperty<LocalDate> fechaProperty() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha.set(fecha);
    }
}
