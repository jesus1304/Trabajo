package com.nebrija.javafx_holamundo;

import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.Alert.AlertType;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.gson.Gson;
import java.lang.reflect.Type;
import com.nebrija.javafx_holamundo.modelo.Cliente;
import com.nebrija.javafx_holamundo.modelo.Proveedor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import javafx.application.Platform;



public class MostrarControlador {

 @FXML
 private TableView<Cliente> tablaDatos;

 @FXML
 private TextField textoUser;

 @FXML
 private TextField correo;

 @FXML
 private TextField textoApellido;

 @FXML
 private TextField idCliente;

 @FXML
 private TextField contraseña;

 @FXML
 private TextField nombre;

 @FXML
 private TextField textoTelefono;

 @FXML
 private TableColumn<Cliente, String> colNombre, colIdCliente, colTelefono, colCorreo, colUser, colApellido, colContraseña;

 private List<Cliente> listaClientes;

 private ApiService apiService;

 @FXML
 private void initialize() {
     creaTablaClientes();

     Task<Void> cargarClientesTask = new Task<Void>() {
         @Override
         protected Void call() throws Exception {
             cargarClientes();
             return null;
         }
     };

     cargarClientesTask.setOnSucceeded(event -> {
         Platform.runLater(() -> {
             ObservableList<Cliente> observableClientes = FXCollections.observableArrayList(listaClientes);
             tablaDatos.setItems(observableClientes);
         });
     });

     new Thread(cargarClientesTask).start();

     Retrofit retrofit = new Retrofit.Builder()
         .baseUrl("http://localhost:8082/")
         .addConverterFactory(GsonConverterFactory.create())
         .build();
     apiService = retrofit.create(ApiService.class);
 }

 private void creaTablaClientes() {
     colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
     colTelefono.setCellValueFactory(new PropertyValueFactory<>("telefono"));
     colCorreo.setCellValueFactory(new PropertyValueFactory<>("correo"));
     colUser.setCellValueFactory(new PropertyValueFactory<>("user"));
     colApellido.setCellValueFactory(new PropertyValueFactory<>("apellido"));
     colContraseña.setCellValueFactory(new PropertyValueFactory<>("contraseña"));
     colIdCliente.setCellValueFactory(new PropertyValueFactory<>("idCliente"));
 }

 private void cargarClientes() {
     try {
         String clientesJson = fetch("http://localhost:8082/listarClientes");
         Gson gson = new Gson();
         Type clienteListType = new TypeToken<List<Cliente>>() {}.getType();
         listaClientes = gson.fromJson(clientesJson, clienteListType);
     } catch (Exception e) {
         e.printStackTrace();
         mostrarAlerta("Error", "No se pudieron cargar los clientes.");
     }
 }

 private String fetch(String url) {
     try {
         URL apiUrl = new URL(url);
         HttpURLConnection connection = (HttpURLConnection) apiUrl.openConnection();
         connection.setRequestMethod("GET");
         int responseCode = connection.getResponseCode();
         if (responseCode == HttpURLConnection.HTTP_OK) {
             BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
             StringBuilder response = new StringBuilder();
             String line;
             while ((line = reader.readLine()) != null) {
                 response.append(line);
             }
             reader.close();
             return response.toString();
         } else {
             return "Error en la solicitud, código de respuesta: " + responseCode;
         }
     } catch (IOException e) {
         e.printStackTrace();
         return "Excepción durante la solicitud: " + e.getMessage();
     }
 }

 private void mostrarAlerta(String titulo, String mensaje) {
     Alert alert = new Alert(AlertType.ERROR);
     alert.setTitle(titulo);
     alert.setHeaderText(null);
     alert.setContentText(mensaje);
     alert.showAndWait();
 }
}

