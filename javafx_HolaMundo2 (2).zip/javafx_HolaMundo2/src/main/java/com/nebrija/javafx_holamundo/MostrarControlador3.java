package com.nebrija.javafx_holamundo;
import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.application.Platform;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.nebrija.javafx_holamundo.modelo.Factura;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

public class MostrarControlador3 {

    @FXML
    private TableView<Factura> tablaDatos;

    @FXML
    private TextField textoUser;

    @FXML
    private TextField direccion;

    @FXML
    private TextField fecha;

    @FXML
    private TextField precio;

    @FXML
    private TextField factura;

    @FXML
    private TextField totalPrecio;

    @FXML
    private TextField totalPrecioCompras;

    @FXML
    private TableColumn<Factura, String> colUser, colDireccion, colFecha, colPrecio, colFactura;

    @FXML
    private BarChart<String, Double> graficoBarras; // Añadir el gráfico de barras

    private List<Factura> listaFacturas;

    private ApiService apiService;

    @FXML
    private void initialize() {
        creaTablaFacturas();
        creaGraficoBarras(); // Llamar al método para crear el gráfico de barras

        Task<Void> cargarFacturasTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                cargarFacturas();
                return null;
            }
        };

        cargarFacturasTask.setOnSucceeded(event -> {
            Platform.runLater(() -> {
                ObservableList<Factura> observableFacturas = FXCollections.observableArrayList(listaFacturas);
                tablaDatos.setItems(observableFacturas);
                // Calcular y mostrar la suma de precios de ventas
                double totalVentas = calcularTotalPrecios("Venta");
                totalPrecio.setText(String.valueOf(totalVentas));
                // Calcular y mostrar la suma de precios de compras
                double totalCompras = calcularTotalPrecios("Compra");
                totalPrecioCompras.setText(String.valueOf(totalCompras));
                // Actualizar el gráfico de barras con los datos
                actualizarGraficoBarras();
            });
        });

        new Thread(cargarFacturasTask).start();

        Retrofit retrofit = new Retrofit.Builder().baseUrl("http://localhost:8082/")
                .addConverterFactory(GsonConverterFactory.create()).build();
        apiService = retrofit.create(ApiService.class);
    }

    private void creaTablaFacturas() {
        colUser.setCellValueFactory(new PropertyValueFactory<>("user"));
        colDireccion.setCellValueFactory(new PropertyValueFactory<>("direccion"));
        colFecha.setCellValueFactory(new PropertyValueFactory<>("fecha"));
        colPrecio.setCellValueFactory(new PropertyValueFactory<>("precio"));
        colFactura.setCellValueFactory(new PropertyValueFactory<>("factura"));
    }

    private void creaGraficoBarras() {
        CategoryAxis xAxis = new CategoryAxis();
        xAxis.setLabel("Años");

        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Total Precio");

        graficoBarras = new BarChart<>(xAxis, yAxis); 

        graficoBarras.setTitle("Total de precios por año");
        graficoBarras.setLegendVisible(true);
        graficoBarras.setCategoryGap(10);

        graficoBarras.setBarGap(10);

        graficoBarras.getXAxis().setTickLabelRotation(90);

        graficoBarras.getXAxis().setAnimated(false);
        graficoBarras.getYAxis().setAnimated(false);

        graficoBarras.setAnimated(false);
    }

    private void actualizarGraficoBarras() {
        graficoBarras.getData().clear();

        XYChart.Series<String, Double> series = new XYChart.Series<>();

        for (Factura factura : listaFacturas) {
            String year = factura.getFecha().substring(0, 4); // Obtener el año de la fecha
            series.getData().add(new XYChart.Data<>(year, factura.getPrecio()));
        }

        graficoBarras.getData().add(series);
    }

    private void cargarFacturas() {
        try {
            String facturasJson = fetch("http://localhost:8082/listarFacturas");
            Gson gson = new Gson();
            Type facturaListType = new TypeToken<List<Factura>>() {
            }.getType();
            listaFacturas = gson.fromJson(facturasJson, facturaListType);
        } catch (Exception e) {
            e.printStackTrace();
            mostrarAlerta("Error", "No se pudieron cargar las facturas.");
        }
    }

    private double calcularTotalPrecios(String tipoFactura) {
        double total = 0.0;
        for (Factura factura : listaFacturas) {
            if (tipoFactura.equals(factura.getFactura())) {
                total += factura.getPrecio();
            }
        }
        return total;
    }

    private String fetch(String url) {
        try {
            URL apiUrl = new URL(url);
            HttpURLConnection connection = (HttpURLConnection) apiUrl.openConnection();
            connection.setRequestMethod("GET");
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();
                return response.toString();
            } else {
                return "Error en la solicitud, código de respuesta: " + responseCode;
            }
        } catch (IOException e) {
            e.printStackTrace();
            return "Excepción durante la solicitud: " + e.getMessage();
        }
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}