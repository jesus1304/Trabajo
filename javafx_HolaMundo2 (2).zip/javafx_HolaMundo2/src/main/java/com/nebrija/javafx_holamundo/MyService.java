package com.nebrija.javafx_holamundo;

import java.util.List;

import com.nebrija.javafx_holamundo.modelo.Cliente;

import javafx.concurrent.Service;
import javafx.concurrent.Task;
import okhttp3.Response;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MyService extends Service{
	Retrofit retrofit = new Retrofit.Builder()
	        .baseUrl("http://localhost:8082/")
	        .addConverterFactory(GsonConverterFactory.create())
	        .build();
	@Override
	protected Task<List<Cliente>>createTask() {
		// TODO Auto-generated method stub
		return new Task <List<Cliente>>() {
			@Override
			protected List<Cliente> call() throws Exception {
				// TODO Auto-generated method stub
				ApiService apiService=retrofit.create(ApiService.class);	
				Call<List<Cliente>> call=apiService.getClientes();
				retrofit2.Response<List<Cliente>> response=call.execute();
				if(response.isSuccessful()) {
					return response.body();
				}else {
					return null;
				}
				
			}
		};
	}
}
