package com.nebrija.javafx_holamundo;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import java.io.IOException;

import com.nebrija.javafx_holamundo.modelo.Proveedor;

public class PrimaryController2 {

    @FXML
    private TextField textoUser;

    @FXML
    private TextField correo;

    @FXML
    private TextField textoApellido;

    @FXML
    private TextField idProveedor;

    @FXML
    private TextField contraseña;

    @FXML
    private TextField nombre;

    @FXML
    private TextField textoTelefono;

    private ApiService apiService;

    @FXML
    private void initialize() {
        Retrofit retrofit = new Retrofit.Builder()
            .baseUrl("http://localhost:8082/")
            .addConverterFactory(GsonConverterFactory.create())
            .build();
        apiService = retrofit.create(ApiService.class);
    }

    @FXML
    void salvarDatos(javafx.event.ActionEvent event) {
        Proveedor proveedor = new Proveedor(
                nombre.getText(),
                textoTelefono.getText(),
                correo.getText(),
                textoApellido.getText()
        );
        System.out.println(proveedor.toString());

        // Enviar datos al servidor usando Retrofit
        Call<Void> call = apiService.guardarProveedor(proveedor);
        try {
            Response<Void> response = call.execute();
            if (response.isSuccessful()) {
                mostrarAlerta("Guardar Proveedor", "Proveedor guardado correctamente");
            } else {
                mostrarAlerta("Guardar Proveedor", "Error al guardar el proveedor: " + response.message());
            }
        } catch (IOException e) {
            e.printStackTrace();
            mostrarAlerta("Guardar Proveedor", "Excepción durante la solicitud: " + e.getMessage());
        }
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}
