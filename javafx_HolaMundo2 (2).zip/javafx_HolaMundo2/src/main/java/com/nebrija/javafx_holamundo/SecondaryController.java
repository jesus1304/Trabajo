package com.nebrija.javafx_holamundo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class SecondaryController {

    @FXML
    private TextField nombre;

    @FXML
    private PasswordField contraseña;

    @FXML
    private void loginButtonAction() {
    	
       
    	 String username = nombre.getText();
    	    String password = contraseña.getText();

    	    if (username.equals("usuario") && password.equals("contraseña")) {
    	        mostrarAlerta("Inicio de Sesión Exitoso", "¡Bienvenido, " + username + "!");
    	        // Lanzar el Task en un nuevo hilo
    	        Thread thread = new Thread(fetchTask);
    	        thread.start();
    	    } else {
    	        mostrarAlerta("Error de Inicio de Sesión", "Usuario o contraseña incorrectos.");
    	    }
    	}
    // Mueve el Task fuera del método loginButtonAction()
    Task<String> fetchTask = new Task<String>() {
        @Override
        protected String call() throws Exception {
            return fetch("http://localhost:8082/listarClientes");
        }
    };
    private String fetch(String url) {
        try {
            URL apiUrl = new URL(url);
            HttpURLConnection connection = (HttpURLConnection) apiUrl.openConnection();
            connection.setRequestMethod("GET");
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();
                return response.toString();
            } else {
                return "Error en la solicitud, código de respuesta: " + responseCode;
            }
        } catch (IOException e) {
            e.printStackTrace();
            return "Excepción durante la solicitud: " + e.getMessage();
        }
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}
