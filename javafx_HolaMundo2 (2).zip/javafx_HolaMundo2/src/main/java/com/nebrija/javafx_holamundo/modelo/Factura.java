package com.nebrija.javafx_holamundo.modelo;
public class Factura {

    private String factura;
    private String user;
    private String Nif;
    private String direccion;
    private String fecha;
    private int precio; // Cambiado a int

    // Constructor vacío
    public Factura() {
    }

    // Constructor con todos los campos
    public Factura(String factura, String user, String Nif, String direccion, String fecha, int precio) { // Cambiado a int
        this.factura = factura;
        this.user = user;
        this.Nif = Nif;
        this.direccion = direccion;
        this.fecha = fecha;
        this.precio = precio;
    }

    public String getFactura() {
        return factura;
    }

    public void setFactura(String factura) {
        this.factura = factura;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getNif() {
        return Nif;
    }

    public void setNif(String Nif) {
        this.Nif = Nif;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public int getPrecio() { // Cambiado a int
        return precio;
    }

    public void setPrecio(int precio) { // Cambiado a int
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Factura [factura=" + factura + ", user=" + user + ", Nif=" + Nif + ", direccion=" + direccion
                + ", fecha=" + fecha + ", precio=" + precio + "]";
    }
}
