package com.nebrija.javafx_holamundo;

import java.util.List;

import com.nebrija.javafx_holamundo.modelo.Cliente;
import com.nebrija.javafx_holamundo.modelo.Factura;
import com.nebrija.javafx_holamundo.modelo.Proveedor;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface ApiService {
    @GET("listarClientes")
    Call<List<Cliente>> getClientes();

    @POST("/guardarCliente")
    Call<Void> guardarCliente(@Body Cliente cliente);
    @GET("listarProveedores")
    Call<List<Proveedor>> getProveedores();

    @POST("/guardarProveedor")
    Call<Void> guardarProveedor(@Body Proveedor proveedor);
    @GET("listarFacturas")
    Call<List<Factura>> getFacturas();
    @DELETE("eliminarCliente/{idCliente}")
    Call<Void> eliminarCliente(@Path("idCliente") int idCliente);

}
