package com.nebrija.javafx_holamundo;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import javafx.beans.property.*;

public class Persona2 {

    private StringProperty nombre;
    private StringProperty contraseña;

	public Persona2() {
		super();
	}
	public Persona2(String nombre, String contraseña
			) {
		super();
		   this.nombre = new SimpleStringProperty(nombre);
	        this.contraseña = new SimpleStringProperty(contraseña);

	}


	public StringProperty getNombre() {
		return nombre;
	}


	public void setNombre(StringProperty nombre) {
		this.nombre = nombre;
	}


	public StringProperty getContraseña() {
		return contraseña;
	}


	public void setContraseña(StringProperty contraseña) {
		this.contraseña = contraseña;
	}
}