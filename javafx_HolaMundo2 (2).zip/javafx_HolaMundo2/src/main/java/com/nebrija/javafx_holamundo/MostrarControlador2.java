package com.nebrija.javafx_holamundo;

import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.Alert.AlertType;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.gson.Gson;
import java.lang.reflect.Type;
import com.nebrija.javafx_holamundo.modelo.Cliente;
import com.nebrija.javafx_holamundo.modelo.Proveedor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import javafx.application.Platform;


public class MostrarControlador2 {

	 @FXML
	 private TableView<Proveedor> tablaDatos;

	 @FXML
	 private TextField correo;

	 @FXML
	 private TextField textoApellido;

	 @FXML
	 private TextField idProveedor;


	 @FXML
	 private TextField nombre;

	 @FXML
	 private TextField textoTelefono;

	 @FXML
	 private TableColumn<Proveedor, String> colNombre, colIdProveedor, colTelefono, colCorreo, colApellido;

	 private List<Proveedor> listaProveedores;

	 private ApiService apiService;

	 @FXML
	 private void initialize() {
	     creaTablaProveedores();

	     Task<Void> cargarProveedoresTask = new Task<Void>() {
	         @Override
	         protected Void call() throws Exception {
	             cargarProveedores();
	             return null;
	         }
	     };

	     cargarProveedoresTask.setOnSucceeded(event -> {
	         Platform.runLater(() -> {
	             ObservableList<Proveedor> observableProveedores = FXCollections.observableArrayList(listaProveedores);
	             tablaDatos.setItems(observableProveedores);
	         });
	     });

	     new Thread(cargarProveedoresTask).start();

	     Retrofit retrofit = new Retrofit.Builder()
	         .baseUrl("http://localhost:8082/")
	         .addConverterFactory(GsonConverterFactory.create())
	         .build();
	     apiService = retrofit.create(ApiService.class);
	 }

	 private void creaTablaProveedores() {
	     colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
	     colTelefono.setCellValueFactory(new PropertyValueFactory<>("telefono"));
	     colCorreo.setCellValueFactory(new PropertyValueFactory<>("correo"));
	     colApellido.setCellValueFactory(new PropertyValueFactory<>("apellido"));
	     colIdProveedor.setCellValueFactory(new PropertyValueFactory<>("idProveedor"));
	 }

	 private void cargarProveedores() {
	     try {
	         String proveedoresJson = fetch("http://localhost:8082/listarProveedores");
	         Gson gson = new Gson();
	         Type proveedorListType = new TypeToken<List<Proveedor>>() {}.getType();
	         listaProveedores = gson.fromJson(proveedoresJson, proveedorListType);
	     } catch (Exception e) {
	         e.printStackTrace();
	         mostrarAlerta("Error", "No se pudieron cargar los proveedores.");
	     }
	 }

	 private String fetch(String url) {
	     try {
	         URL apiUrl = new URL(url);
	         HttpURLConnection connection = (HttpURLConnection) apiUrl.openConnection();
	         connection.setRequestMethod("GET");
	         int responseCode = connection.getResponseCode();
	         if (responseCode == HttpURLConnection.HTTP_OK) {
	             BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	             StringBuilder response = new StringBuilder();
	             String line;
	             while ((line = reader.readLine()) != null) {
	                 response.append(line);
	             }
	             reader.close();
	             return response.toString();
	         } else {
	             return "Error en la solicitud, código de respuesta: " + responseCode;
	         }
	     } catch (IOException e) {
	         e.printStackTrace();
	         return "Excepción durante la solicitud: " + e.getMessage();
	     }
	 }

	 private void mostrarAlerta(String titulo, String mensaje) {
	     Alert alert = new Alert(AlertType.ERROR);
	     alert.setTitle(titulo);
	     alert.setHeaderText(null);
	     alert.setContentText(mensaje);
	     alert.showAndWait();
	 }
	}
