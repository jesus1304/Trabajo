package com.nebrija.javafx_holamundo;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class FormularioDatos {
	@FXML
    private Label etiquetaPrincipal;
    @FXML
    private Button boton;

    @FXML
    private TableView<Persona> tablaDatos;

    @FXML
    private TextField textoDireccion;

    @FXML
    private TextField precio;

    @FXML
    private TextField textoNombre;

    @FXML
    private TableColumn<Persona, String> colNombre, colDireccion;

    @FXML
    private TableColumn<Persona, Integer> colPrecio;

    @FXML
    private TableColumn<Persona, LocalDate> colFecha;

    private List<Persona> listaPersonas;

    // Agregar referencia al controlador primario
    private PrimaryController primaryController;

    // Método para establecer la referencia al controlador primario
    public void setPrimaryController(PrimaryController primaryController) {
        this.primaryController = primaryController;
    }

    @FXML
    void entraBoton(javafx.scene.input.MouseEvent event) {
        boton.setText("Guardar Factura");
    }

    @FXML
    void saleBoton(javafx.scene.input.MouseEvent event) {
        boton.setText("Guardar Factura");
    }

    @FXML
    void cambiarVista(javafx.event.ActionEvent event) throws IOException {
        App.setRoot("primary");
    }

    @FXML
    void salvarDatos(javafx.event.ActionEvent event) {
        // Get current date
        LocalDate currentDate = LocalDate.now();

        // Create Persona with the current date
        Persona persona = new Persona(
                textoNombre.getText(),
                Integer.parseInt(precio.getText()),
                textoDireccion.getText(),
                currentDate);

        // Add persona to the list
        listaPersonas.add(persona);

        // Set cell value factories only once during initialization
        colNombre.setCellValueFactory(cellData -> cellData.getValue().nombreProperty());
        colPrecio.setCellValueFactory(cellData -> cellData.getValue().precioProperty().asObject());
        colDireccion.setCellValueFactory(cellData -> cellData.getValue().direccionProperty());
        colFecha.setCellValueFactory(cellData -> cellData.getValue().fechaProperty());

        tablaDatos.getItems().setAll(listaPersonas);

        // Llamar al método para actualizar la suma de precios en el controlador PrimaryController
        actualizarSumaPrecios();

        // Limpiar los campos después de agregar la persona
        limpiarCampos();
    }

    @FXML
    private void initialize() {
        creaTabla();
        listaPersonas = new ArrayList<>();
    }

    void creaTabla() {
        colNombre = new TableColumn<>("Nombre");
        colPrecio = new TableColumn<>("Precio");
        colDireccion = new TableColumn<>("Dirección");
        colFecha = new TableColumn<>("Fecha");

        tablaDatos.getColumns().addAll(colNombre, colPrecio, colDireccion, colFecha);
    }

    private void limpiarCampos() {
        textoNombre.clear();
        precio.clear();
        textoDireccion.clear();
    }

    // Método para actualizar la suma de precios en el controlador PrimaryController
    private void actualizarSumaPrecios() {
        if (primaryController != null) {
            // Llamar al método actualizarSumaPrecios y pasar la lista de personas
        }
    }
    
}

