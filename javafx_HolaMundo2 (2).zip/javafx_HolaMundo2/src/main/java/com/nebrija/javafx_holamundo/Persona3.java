package com.nebrija.javafx_holamundo;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Persona3 {
    private StringProperty nombre;
    private IntegerProperty idCliente;
    private StringProperty telefono;
    private StringProperty correo;
    private StringProperty user;
    private StringProperty apellido;
    private StringProperty contraseña;

    // Constructor
    public Persona3(String nombre, int idCliente, String telefono, String correo, String user, String apellido, String contraseña) {
        this.nombre = new SimpleStringProperty(nombre);
        this.idCliente = new SimpleIntegerProperty(idCliente);
        this.telefono = new SimpleStringProperty(telefono);
        this.correo = new SimpleStringProperty(correo);
        this.user = new SimpleStringProperty(user);
        this.apellido = new SimpleStringProperty(apellido);
        this.contraseña = new SimpleStringProperty(contraseña);
    }

    // Getters y Setters
    public String getNombre() {
        return nombre.get();
    }

    public StringProperty nombreProperty() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre.set(nombre);
    }

    public int getIdCliente() {
        return idCliente.get();
    }

    public IntegerProperty idClienteProperty() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente.set(idCliente);
    }

    public String getTelefono() {
        return telefono.get();
    }

    public StringProperty telefonoProperty() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono.set(telefono);
    }

    public String getCorreo() {
        return correo.get();
    }

    public StringProperty correoProperty() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo.set(correo);
    }

    public String getUser() {
        return user.get();
    }

    public StringProperty userProperty() {
        return user;
    }

    public void setUser(String user) {
        this.user.set(user);
    }

    public String getApellido() {
        return apellido.get();
    }

    public StringProperty apellidoProperty() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido.set(apellido);
    }

    public String getContraseña() {
        return contraseña.get();
    }

    public StringProperty contraseñaProperty() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña.set(contraseña);
    }

    // Método toString para imprimir los datos de la persona
    @Override
    public String toString() {
        return "Persona3{" +
                "nombre=" + nombre.get() +
                ", idCliente=" + idCliente.get() +
                ", telefono=" + telefono.get() +
                ", correo=" + correo.get() +
                ", user=" + user.get() +
                ", apellido=" + apellido.get() +
                ", contraseña=" + contraseña.get() +
                '}';
    }
}
