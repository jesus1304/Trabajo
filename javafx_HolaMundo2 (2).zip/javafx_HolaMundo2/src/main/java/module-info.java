module com.nebrija.javafx_holamundo {
    requires javafx.controls;
    requires javafx.fxml;
	requires com.google.common;
	requires com.google.gson;
	requires retrofit;
	requires okhttp3;
	requires converter.gson;

    opens com.nebrija.javafx_holamundo to javafx.fxml;
    opens com.nebrija.javafx_holamundo.modelo to com.google.gson;

    exports com.nebrija.javafx_holamundo;
    exports com.nebrija.javafx_holamundo.modelo;

}
